package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBrowser {

	public static String browser = "chrome";
	public static WebDriver driver;

	public static void main(String[] args) {

		// System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY,
		// "true");

		System.setProperty("webdriver.chrome.silentOutput", "true");
		if (browser.equals("chrome")) {

			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else if (browser.equals("firefox")) {

			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}

		// 123

		driver.get("http://gmail.com");

		// driver.manage().window().maximize();

		/*
		 * Options opt = driver.manage(); Window win = opt.window(); win.maximize();
		 */

		driver.manage().window().maximize();

		driver.getTitle().length();

		/*
		 * String title = driver.getTitle(); int length = title.length();
		 * System.out.println(length); System.out.println(title);
		 */
		// driver.close();//close current browser
		// driver.quit();//close current browser

	}

}
