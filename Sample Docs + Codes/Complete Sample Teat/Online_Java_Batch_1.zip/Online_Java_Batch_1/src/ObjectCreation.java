
public class ObjectCreation {
	
	public static void main(String[] args) {
		
		
		ObjectCreation obj1= new ObjectCreation();
		
		ObjectCreation obj2= new ObjectCreation();
		
		new ObjectCreation();
		
		System.out.println("Hi");
		System.out.println("Hello");
		
	
		
		
		
		
	}

}
