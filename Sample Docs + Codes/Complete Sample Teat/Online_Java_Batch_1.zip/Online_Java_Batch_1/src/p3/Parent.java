package p3;

public class Parent {
	
	public void add()
	{
		
	}

}
