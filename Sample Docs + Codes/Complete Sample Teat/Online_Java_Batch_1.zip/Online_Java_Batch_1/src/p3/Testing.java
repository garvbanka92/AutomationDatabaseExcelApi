package p3;

public class Testing {
	
	public void sum()
	{
		System.out.println("sum() of Testing  class");
	}
	
	public static void print()
	{
		System.out.println("print() of Testing class");
	}

}
