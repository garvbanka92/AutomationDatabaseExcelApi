package p3;

public class Child extends Parent{
	
	public static void main(String[] args) {
		
		Child p = new Child();
		p.add();
		
	}

}
