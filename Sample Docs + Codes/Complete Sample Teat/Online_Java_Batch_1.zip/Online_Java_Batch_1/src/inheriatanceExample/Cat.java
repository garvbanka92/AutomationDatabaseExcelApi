package inheriatanceExample;

public class Cat extends Animal{
	
	public static void main(String[] args) {
		
		Cat cat = new Cat();
		cat.sound();
	}

}
