package inheriatanceExample;

public class ValidateLoginFunctionality {
	
	public void doLogin(String email, String password)
	{
		
	}
	
	public void doLogin(int mobile, String password)
	{
		
	}
	
	public void validateLoginFunctionality()
	{
		new ValidateLoginFunctionality().
		
	}
	

}
