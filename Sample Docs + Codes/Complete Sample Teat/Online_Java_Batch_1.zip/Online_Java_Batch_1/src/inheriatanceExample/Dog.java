package inheriatanceExample;

public class Dog extends Animal{

	public static void main(String[] args) {
		
		BullDog obj= new BullDog();
		obj.sound();
		
		
	}
	
}
