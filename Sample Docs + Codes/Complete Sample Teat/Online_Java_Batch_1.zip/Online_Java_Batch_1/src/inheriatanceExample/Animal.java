package inheriatanceExample;

public class Animal {
	
	public void sound()
	{
		System.out.println("Generic sound");
	}

}
