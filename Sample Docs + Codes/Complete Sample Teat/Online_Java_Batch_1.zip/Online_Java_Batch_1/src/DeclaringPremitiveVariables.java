
public class DeclaringPremitiveVariables {
	
	
	
	public static void main(String[] args) {
		
		long b=12345689012l;
		
		long var=100;
		
		float var1=0.0f;
		double d=100.25;
		
		//System.out.println(var1);//
		
		char c='a';
		
		char c1=100;
		
		System.out.println(c1);
		
		int i=100;
		System.out.println(i);
		
		
		boolean var11=true;
		
		
	}

}
