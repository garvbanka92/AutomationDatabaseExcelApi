package loops;

public class Test {

	public static void main(String[] args) {
		
		/*for(int i=1;i<=10;i++)
		{
			
			System.out.println(i);// 1 3 5 7 9
			i++;//10
		}*/
		
		int i=11;
		while(i<=10)
		{
			System.out.println(i);
			i++;
		}
		
	}
}
