package operatorsExMple;

public class EqualityOperators {

	public static void main(String[] args) {
		// Equal to operator
		
		/*int i=20;
		double j=20.0;
		System.out.println(++i ==j);*/
		
		String s1="Rahul";
		String s2="Rahul Jha";
		String s3= new String("Rahul");
		//System.out.println(s3);
		//System.out.println(s1==s2);//true
		//System.out.println(s1==s3);//false
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		
		
		int i=10;
		int j=10;
		
	}
}
