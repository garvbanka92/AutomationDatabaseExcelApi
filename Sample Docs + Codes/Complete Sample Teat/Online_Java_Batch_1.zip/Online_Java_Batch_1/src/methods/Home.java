package methods;

public class Home {

	public static void main(String[] args) {
		int a=100;
		int b=200;
		
		System.out.println(a%b);// max(int, int,int)--> int
	}
}
