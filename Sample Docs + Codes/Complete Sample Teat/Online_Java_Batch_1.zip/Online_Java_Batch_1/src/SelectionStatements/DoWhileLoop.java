package SelectionStatements;

public class DoWhileLoop {

	public static void main(String[] args) {

		int i = 11;
		do {
			System.out.println(i);//2
			i++;//3
		} while (i <= 10);// 2<=10
		i++;
		System.out.println(i);

	}

}
