package SelectionStatements;

public class SwitchCaseExample {
	public static void main(String[] args) {

		String day = "monday";

		switch (day) {
		case "monday":
			System.out.println(1);
			break;
		case "tuesday":
			System.out.println(2);
			break;
		case "wednesday":
			System.out.println(3);
			break;

		}

		/*
		 * int day = 7; // day==1 monday // day==2 tuesday // day ==3 wednesday
		 * switch (day)// integer ,string,char,enum { case 1:
		 * 
		 * System.out.println("Monday"); break; case 2:
		 * System.out.println("Tuesday"); break; case 3:
		 * System.out.println("Wednesday"); break; case 4:
		 * System.out.println("Thursday"); break; case 5:
		 * System.out.println("Friday"); break; case 6:
		 * System.out.println("Saturday"); break; case 7:
		 * System.out.println("Sunday"); break;
		 * 
		 * default: System.out.println("None of the cases got matched");
		 * 
		 * 
		 * }
		 */

	}

}
