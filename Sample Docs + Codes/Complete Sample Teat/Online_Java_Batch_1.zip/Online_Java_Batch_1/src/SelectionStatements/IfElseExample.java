package SelectionStatements;

public class IfElseExample {
	
	public static void main(String[] args) {
		
		int i=11;
		if(i%2==0)
		{
			System.out.println("i is even number");
			
		}
		else
		{
			System.out.println("i is odd number");
			
		}
	}

}
