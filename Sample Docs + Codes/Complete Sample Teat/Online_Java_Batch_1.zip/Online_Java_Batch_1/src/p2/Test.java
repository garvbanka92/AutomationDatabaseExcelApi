package p2;

public class Test {
	
	public void add()
	{
		System.out.println("add() of Test class of p2 package");
	}

}
