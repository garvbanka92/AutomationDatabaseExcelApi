package p1;

public class Home {
	
	public static void main(String[] args) {
		
		Test obj = new Test();
		obj.add();
	}
	
	public void display()
	{
		System.out.println("this is display() of Home class of p1 package");
	}

}
