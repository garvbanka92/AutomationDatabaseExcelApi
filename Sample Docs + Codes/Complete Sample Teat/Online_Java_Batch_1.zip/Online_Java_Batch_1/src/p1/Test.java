package p1;

public class Test {
	
	public void add()
	{
		System.out.println("this is add() of Test class of p1 package");
	}

	public static void main(String[] args) {
		
		Test t= new Test();
		t.add();
		
		
	}
}
