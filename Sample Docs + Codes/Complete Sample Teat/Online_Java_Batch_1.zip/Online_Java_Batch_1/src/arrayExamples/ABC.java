package arrayExamples;

public class ABC {

	public static void main(String[] args) {
		
		
		ABC[] arr=new ABC[5];
		
		//need an object of class ABC
		//ABC obj1= new ABC();
		// assigne object into index 0 of the array
		arr[0]= new ABC();
		
		String[] array1= new String[10];
	}
}
