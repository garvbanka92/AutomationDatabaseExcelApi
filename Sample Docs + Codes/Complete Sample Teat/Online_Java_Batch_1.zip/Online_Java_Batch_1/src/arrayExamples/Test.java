package arrayExamples;

public class Test {
	
	public static void main(String[] args) {
		
		int[] array= new int[5];//Array
		
		//insert values in array
			array[0]=10;
			array[1]=20;
			array[2]=30;
			array[3]=40;
			array[4]=50;
			
		
		
		//fetch values from an array
		
			System.out.println(array[4]);//
		
		
		//int array1[]= new int[5];
		//int []array2= new int[5];
		
	}

}
