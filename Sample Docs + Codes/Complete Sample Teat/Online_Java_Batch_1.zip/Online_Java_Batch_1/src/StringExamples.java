
public class StringExamples {
	
	public static void main(String[] args) {
		
		String s1="Rahul";
		
		//String s2="Rahul";
		
		System.out.println(s1);//Rahul
		//System.out.println(s2);
	
		System.out.println("After updation");
		s1="Rahul Arora";
		System.out.println(s1);//Rahul Arora
		
		
		
		
		
		String s3=new String("Abhigya");//2
		String s4="Rahul";
		String s5=new String("Rahul");//1
		
		//int i="Rahul";
		
		
	}

}
