
public class Student {
	
	String studentName="Abhigya";
	int rollNum=101;
	
	public static void main(String[] args) {
		Student student1=new Student();
		
		System.out.println(student1.studentName);
	}
	

}
