
public class Test {
	
	int i=10;
	public static void main(String[] args)
	{
		
		
		Test obj1= new Test();// memory allocation will happen on your system
		
		System.out.println(obj1);
	
		//print value of i
		System.out.println(obj1.i);
		
		new Test();
		
		System.out.println(new Test().i);
		
	
		
		
		
	}

}

