package typeOfVariable;

public class B {

	public static void main(String[] args) {

		int i = 10;
		
		if (i == 10) 
		{
	
			int k=10;
		}
		
			System.out.println("value of i is equal to 10");
		
		System.out.println("end of the code");

	}

}
