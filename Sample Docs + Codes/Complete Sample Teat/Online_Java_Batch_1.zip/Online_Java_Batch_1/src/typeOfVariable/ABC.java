package typeOfVariable;

public class ABC {

	public static void main(String[] args) {
		MethodExample.substract();
	}
}
