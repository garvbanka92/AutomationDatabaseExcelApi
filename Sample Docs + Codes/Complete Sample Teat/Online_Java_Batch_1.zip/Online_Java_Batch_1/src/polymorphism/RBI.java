package polymorphism;

public class RBI {
	
	public double getHomeLoanROI()
	{
		return 7.0;
	}
	
	public double getCarLoanROI()
	{
		return 10.0;
	}
	
	public double getEducationLoanROI()
	{
		return 10;
	}
	
	
	public int getValue()
	{
		return 5;
	}

}
