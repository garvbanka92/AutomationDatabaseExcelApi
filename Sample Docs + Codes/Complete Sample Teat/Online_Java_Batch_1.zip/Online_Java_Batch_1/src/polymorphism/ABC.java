package polymorphism;

public class ABC {
	public static void main(String[] args) {
		
		ABC obj = new ABC();
		obj.add(10.0,20);
	}
	
	public void add(int a, double b)
	{
		
		
	}
	public void add(double a , int b)
	{
		
		
	}
	
	public void add(double a, double b)
	{
		
	}

}
