package polymorphism;

public class WebDriver {
	
	public void click()
	{
		System.out.println("WebDriver click() executed");
	}
	
	public void sendKeys(String str)
	{
		System.out.println("WebDriver sendKeys() executed");
	}

}
