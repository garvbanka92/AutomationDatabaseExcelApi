package polymorphism;

public class PNB extends RBI{
	
	public double getHomeLoanROI()
	{
		return 8.2;
	}
	
	public double getCarLoanROI()
	{
		return 11.3;
	}
	
	public double getEducationLoanROI()
	{
		return 12.7;
		
	}

}
