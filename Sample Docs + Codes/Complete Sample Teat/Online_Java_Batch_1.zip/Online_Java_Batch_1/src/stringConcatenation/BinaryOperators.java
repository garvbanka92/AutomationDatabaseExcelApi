package stringConcatenation;

public class BinaryOperators {

	public static void main(String[] args) {
		/*
		 * int a=13; double b=2; System.out.println(a/b);//
		 
		int b = 100;
		 b=b+10;//max(int,byte,int)--> int
		System.out.println(b);//
		
		float l=100f;
		float f=10.5f;
		l=l+f;//max(int,long,float)-->float
*/
		
		int s=10;
		char c='a';
		//s=s+c;//max(int,short,char)--> int
		System.out.println(s);
		
		/*boolean b1=true;
		boolean b2=false;
		System.out.println(b1+b2);*/
		
		//max(int, float,double)-->double
		
		
		
		
	}

}
