package abstractClassAndInterface;

public interface RBI {
	
	public void getHomeLoanROI();

}
