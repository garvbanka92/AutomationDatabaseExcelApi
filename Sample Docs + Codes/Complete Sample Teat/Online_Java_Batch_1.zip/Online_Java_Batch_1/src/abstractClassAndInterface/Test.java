package abstractClassAndInterface;

public class Test {

	public final static void main(String[] args) {
		//WebDriver driver = new WebDriver();
		
		final int i=10;
		System.out.println(i);
		//i=200;
	}

}
