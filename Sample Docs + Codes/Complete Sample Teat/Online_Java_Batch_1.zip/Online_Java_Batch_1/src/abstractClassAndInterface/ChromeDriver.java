package abstractClassAndInterface;

public class ChromeDriver extends WebDriver {

	public void click() {

	}

	public void sendKeys(String str) {

	}

	public void clear() {

	}
}
