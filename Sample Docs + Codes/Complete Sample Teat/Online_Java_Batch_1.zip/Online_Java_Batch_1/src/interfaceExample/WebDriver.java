package interfaceExample;

public interface WebDriver {
	
	public void click();//definition
	public void sendKeys(String s);
	
	

}
