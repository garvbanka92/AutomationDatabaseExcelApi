package interfaceExample;

public class FirefoxDriver implements WebDriver {
	
	public void click()
	{
		
	}
	
	public void sendKeys(String s)
	{
		
	}

}
