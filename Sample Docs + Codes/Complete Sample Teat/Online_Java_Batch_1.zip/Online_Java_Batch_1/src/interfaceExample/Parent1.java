package interfaceExample;

public interface Parent1 {
	
	public void p1();
	public static void m1()
	{
		
	}

}
