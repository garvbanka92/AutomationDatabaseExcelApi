package interfaceExample;

public interface Parent2 {
	
	public void p1();

}
