package interfaceExample;

public class ChromeDriver implements WebDriver {

	
	public void click()
	{
		
	}
	public void sendKeys(String s)
	{
		
	}
}
