package testcases;

import org.openqa.selenium.By;

public class TestConcat {

	public static void main(String[] args) {

		for (int i = 1; i <= 4; i++) {

			System.out.println("//input["+i+"]");

		}

	}

}
